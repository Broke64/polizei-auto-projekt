from flask import Flask, render_template, redirect, url_for
import hardware as hw

app = Flask(__name__)

# Zustand des Autos
state = {
    "verriegelt": True,
    "blinker": "A",        # A = aus, L = links, R = rechts, B = Warnblinker
    "blaulicht": False,
    "sirene": False,
    "anzeige": None,       # temperatur / abstand / uhrzeit / spannung
}


@app.route("/")
def index():
    return render_template("index.html", state=state)


@app.route("/verriegelung", methods=["POST"])
def verriegelung():
    state["verriegelt"] = not state["verriegelt"]
    if state["verriegelt"]:               # beim Verriegeln alles ausschalten
        hw.blinker("A")
        hw.blaulicht(False)
        hw.sirene(False)
        hw.anzeige(None)
        state["blinker"] = "A"
        state["blaulicht"] = False
        state["sirene"] = False
        state["anzeige"] = None
    return redirect(url_for("index"))


@app.route("/blinker/<seite>", methods=["POST"])
def blinker(seite):
    if not state["verriegelt"] and seite in ("L", "R", "B"):
        neu = "A" if state["blinker"] == seite else seite   # nochmal druecken = aus
        hw.blinker(neu)
        state["blinker"] = neu
    return redirect(url_for("index"))


@app.route("/blaulicht", methods=["POST"])
def blaulicht():
    if not state["verriegelt"]:
        state["blaulicht"] = not state["blaulicht"]
        hw.blaulicht(state["blaulicht"])
    return redirect(url_for("index"))


@app.route("/anzeige/<art>", methods=["POST"])
def anzeige(art):
    if not state["verriegelt"] and art in ("temperatur", "abstand", "uhrzeit", "spannung"):
        neu = None if state["anzeige"] == art else art
        hw.anzeige(neu)
        state["anzeige"] = neu
    return redirect(url_for("index"))


@app.route("/hupe", methods=["POST"])
def hupe():
    if not state["verriegelt"]:
        hw.hupe()
    return redirect(url_for("index"))


@app.route("/sirene", methods=["POST"])
def sirene():
    if not state["verriegelt"]:
        state["sirene"] = not state["sirene"]
        hw.sirene(state["sirene"])
    return redirect(url_for("index"))


if __name__ == "__main__":
    try:
        app.run(host="0.0.0.0", port=5000)
    finally:
        hw.alles_aus()
