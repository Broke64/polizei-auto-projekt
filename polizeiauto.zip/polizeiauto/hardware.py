"""Hardware-Steuerung (aus euren Dateien led_polizei.py und sound_polizei.py).
Pins bitte an euren Aufbau anpassen!"""
import threading
from gpiozero import PWMLED, TonalBuzzer
from gpiozero.tones import Tone

# ---------------- Pins ----------------
PIN_GELB_LINKS = 24
PIN_GELB_RECHTS = 23
PIN_BLAU_LINKS = 5      # ACHTUNG: in eurem Code war es 24 -> Pin-Konflikt mit dem Blinker!
PIN_BLAU_RECHTS = 6     # ACHTUNG: in eurem Code war es 23
PIN_BUZZER = 22

gelb_links = PWMLED(PIN_GELB_LINKS)
gelb_rechts = PWMLED(PIN_GELB_RECHTS)
blau_links = PWMLED(PIN_BLAU_LINKS)
blau_rechts = PWMLED(PIN_BLAU_RECHTS)
buzzer = TonalBuzzer(PIN_BUZZER, octaves=2)


# ---------------- Blinker ----------------
def blinker(seite):
    """L, R, B (Warnblinker) oder A (aus)"""
    gelb_links.off()
    gelb_rechts.off()
    seite = seite.upper()
    if seite in ("L", "B"):
        gelb_links.blink(on_time=0.5, off_time=0.5)
    if seite in ("R", "B"):
        gelb_rechts.blink(on_time=0.5, off_time=0.5)


# ---------------- Blaulicht (Double-Flash) ----------------
double_flash = [(True, 0.05), (False, 0.05), (True, 0.05), (False, 0.25)]
_blau_stop = threading.Event()
_blau_lock = threading.Lock()
_blau_thread = None


def _blau_muster():
    while not _blau_stop.is_set():
        for an, dauer in double_flash:
            if an:
                blau_links.on()
                blau_rechts.on()
            else:
                blau_links.off()
                blau_rechts.off()
            if _blau_stop.wait(dauer):
                break
    blau_links.off()
    blau_rechts.off()


def blaulicht(an):
    global _blau_thread
    with _blau_lock:
        if an:
            if _blau_thread and _blau_thread.is_alive():
                return
            _blau_stop.clear()
            _blau_thread = threading.Thread(target=_blau_muster, daemon=True)
            _blau_thread.start()
        else:
            _blau_stop.set()
            if _blau_thread:
                _blau_thread.join()


# ---------------- Sound (Hupe + Sirene teilen sich einen Buzzer) ----------------
_sound_stop = threading.Event()
_sound_lock = threading.Lock()
_sound_thread = None
_sirene_aktiv = False


def _stoppe_sound():
    global _sound_thread
    _sound_stop.set()
    if _sound_thread and _sound_thread.is_alive():
        _sound_thread.join()
    _sound_thread = None
    buzzer.stop()


def _starte_sound(ziel):
    global _sound_thread
    _sound_stop.clear()
    _sound_thread = threading.Thread(target=ziel, daemon=True)
    _sound_thread.start()


def _sirene_loop():
    while not _sound_stop.is_set():
        buzzer.play(Tone(frequency=480))
        if _sound_stop.wait(0.8):
            break
        buzzer.play(Tone(frequency=360))
        if _sound_stop.wait(0.8):
            break
    buzzer.stop()


def _hupe_ablauf():
    buzzer.play(Tone(frequency=420))
    _sound_stop.wait(0.5)       # 0,5 Sekunden hupen
    buzzer.stop()
    if _sirene_aktiv and not _sound_stop.is_set():
        _sirene_loop()          # danach Sirene weiterlaufen lassen


def sirene(an):
    global _sirene_aktiv
    with _sound_lock:
        _stoppe_sound()
        _sirene_aktiv = an
        if an:
            _starte_sound(_sirene_loop)


def hupe():
    with _sound_lock:
        _stoppe_sound()
        _starte_sound(_hupe_ablauf)


# ---------------- Anzeige am Auto ----------------
def anzeige(art):
    """Hier kommt euer Display-Code rein.
    art = temperatur / abstand / uhrzeit / spannung / None (aus)"""
    print("Anzeige am Auto:", art)


def alles_aus():
    blinker("A")
    blaulicht(False)
    with _sound_lock:
        _stoppe_sound()
